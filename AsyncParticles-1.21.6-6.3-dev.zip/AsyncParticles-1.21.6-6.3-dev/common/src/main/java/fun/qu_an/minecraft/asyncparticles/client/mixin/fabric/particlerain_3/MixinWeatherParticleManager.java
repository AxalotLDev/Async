package fun.qu_an.minecraft.asyncparticles.client.mixin.fabric.particlerain_3;

import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
import fun.qu_an.minecraft.asyncparticles.client.compat.particlerain.ParticleRainCompat;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import pigcart.particlerain.WeatherParticleManager;

@Mixin(value = WeatherParticleManager.class, remap = false)
public class MixinWeatherParticleManager {
	@ModifyExpressionValue(method = "spawnParticle", at = @At(value = "FIELD", target = "Lpigcart/particlerain/WeatherParticleManager;particleCount:I"))
	private static int modifyParticleCount(int original) {
		return ParticleRainCompat.asyncparticles$particleCount.get();
	}

	@ModifyExpressionValue(method = "spawnParticle", at = @At(value = "FIELD", target = "Lpigcart/particlerain/WeatherParticleManager;fogCount:I"))
	private static int modifyFogCount(int original) {
		return ParticleRainCompat.asyncparticles$fogCount.get();
	}

	@Inject(method = "resetParticleCount", at = @At("HEAD"))
	private static void resetParticleCount(CallbackInfo ci) {
		ParticleRainCompat.clearCounters();
	}
}
